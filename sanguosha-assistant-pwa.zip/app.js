// 三国杀助手 - 移动端应用逻辑

let currentTab = 'heroes';
let heroFilter = { faction: 'all', search: '' };
let cardFilter = { type: 'all', search: '' };
let deferredPrompt = null;

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  renderHeroes();
  renderCards();
  renderRules();
  renderAskExamples();
  setupInstallBanner();
});

// ===== TABS =====
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    const id = tab.dataset.tab + 'Page';
    document.getElementById(id).classList.add('active');
    currentTab = tab.dataset.tab;
    if (currentTab === 'ask') {
      document.getElementById('askResult').innerHTML = '';
    }
  });
});

// ===== HEROES =====
function renderHeroes(heroes = HEROES) {
  const list = document.getElementById('heroList');
  const filtered = heroes.filter(h => {
    if (heroFilter.faction !== 'all' && h.faction !== heroFilter.faction) return false;
    if (heroFilter.search) {
      const s = heroFilter.search.toLowerCase();
      if (!h.name.toLowerCase().includes(s) && !h.title.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    list.innerHTML = '<div class="not-found">没有找到匹配的武将</div>';
    return;
  }

  list.innerHTML = filtered.map(h => `
    <div class="hero-card" onclick="toggleHero(this)">
      <div class="hero-card-header">
        <div class="hero-avatar faction-${h.faction}">${h.name[0]}</div>
        <div>
          <div class="hero-name">${h.name} <span style="font-size:11px;color:var(--text2)">${h.title}</span></div>
          <div class="hero-health">⚔️ ${h.faction} &nbsp; ❤️ ${h.health}体力</div>
        </div>
        <div class="hero-arrow">▼</div>
      </div>
      <div class="hero-skills">
        ${h.skills.map(s => `
          <div class="skill-item">
            <div class="skill-name">【${s.name}】<span class="skill-type">${s.type}</span></div>
            <div class="skill-desc">${s.description}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

function toggleHero(card) {
  card.classList.toggle('open');
}

document.getElementById('heroSearch').addEventListener('input', e => {
  heroFilter.search = e.target.value;
  renderHeroes();
});

document.getElementById('factionPills').addEventListener('click', e => {
  const pill = e.target.closest('.pill');
  if (!pill) return;
  document.querySelectorAll('#factionPills .pill').forEach(p => p.classList.remove('active'));
  pill.classList.add('active');
  heroFilter.faction = pill.dataset.faction;
  renderHeroes();
});

// ===== CARDS =====
function getAllCards() {
  return [
    ...CARDS.basic_cards.map(c => ({ ...c, _cat: 'basic' })),
    ...CARDS.trick_cards.map(c => ({ ...c, _cat: 'trick' })),
    ...CARDS.equipment_cards.map(c => ({ ...c, _cat: 'equipment' }))
  ];
}

function cardTypeIcon(cat) {
  const map = { basic: '🔴', trick: '🟣', equipment: '🔵' };
  return map[cat] || '🔵';
}

function cardCssClass(cat, name) {
  if (name.includes('马')) return 'horse-card';
  if (cat === 'basic') return 'basic-card';
  if (cat === 'trick') return 'trick-card';
  return 'equip-card';
}

function renderCards() {
  const container = document.getElementById('cardList');
  const all = getAllCards().filter(c => {
    if (cardFilter.type !== 'all' && c._cat !== cardFilter.type) return false;
    if (cardFilter.search) {
      const s = cardFilter.search.toLowerCase();
      if (!c.name.toLowerCase().includes(s) && !c.type.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  if (all.length === 0) {
    container.innerHTML = '<div class="not-found">没有找到匹配的卡牌</div>';
    return;
  }

  const groups = {
    basic: all.filter(c => c._cat === 'basic'),
    trick: all.filter(c => c._cat === 'trick'),
    equipment: all.filter(c => c._cat === 'equipment')
  };

  let html = '';

  if (groups.basic.length > 0 && (cardFilter.type === 'all' || cardFilter.type === 'basic')) {
    html += `<div class="card-section"><div class="section-title">🔴 基本牌</div>${groups.basic.map(c => cardHTML(c)).join('')}</div>`;
  }
  if (groups.trick.length > 0 && (cardFilter.type === 'all' || cardFilter.type === 'trick')) {
    html += `<div class="card-section"><div class="section-title">🟣 锦囊牌</div>${groups.trick.map(c => cardHTML(c)).join('')}</div>`;
  }
  if (groups.equipment.length > 0 && (cardFilter.type === 'all' || cardFilter.type === 'equipment')) {
    html += `<div class="card-section"><div class="section-title">🔵 装备牌</div>${groups.equipment.map(c => cardHTML(c)).join('')}</div>`;
  }

  container.innerHTML = html;
}

function cardHTML(c) {
  return `
    <div class="card-item" onclick="toggleCard(this)">
      <div class="card-header">
        <div class="card-icon ${cardCssClass(c._cat, c.name)}">${c.name}</div>
        <div>
          <div class="card-name">【${c.name}】</div>
          <div class="card-type-label">${c.type}</div>
        </div>
        <div class="card-arrow">▼</div>
      </div>
      <div class="card-detail">
        <div>${c.description}</div>
        ${c.notes ? `<div class="card-note">📌 ${c.notes}</div>` : ''}
        ${c.attack_range ? `<div class="card-note">⚔️ 攻击范围：${c.attack_range}</div>` : ''}
      </div>
    </div>
  `;
}

function toggleCard(item) {
  item.classList.toggle('open');
}

document.getElementById('cardSearch').addEventListener('input', e => {
  cardFilter.search = e.target.value;
  renderCards();
});

document.getElementById('cardTypePills').addEventListener('click', e => {
  const pill = e.target.closest('.pill');
  if (!pill) return;
  document.querySelectorAll('#cardTypePills .pill').forEach(p => p.classList.remove('active'));
  pill.classList.add('active');
  cardFilter.type = pill.dataset.type;
  renderCards();
});

// ===== RULES =====
function renderRules() {
  const list = document.getElementById('rulesList');
  let html = '';

  // Basic rules
  RULES.basic_rules.forEach(r => {
    html += `
      <div class="rule-card">
        <div class="rule-header" onclick="toggleRule(this.parentElement)">
          <span>📖 ${r.title}</span>
          <span class="rule-arrow">▼</span>
        </div>
        <div class="rule-body">${r.content.replace(/\n/g, '<br/>')}</div>
      </div>
    `;
  });

  // Skill types
  html += `<div class="section-title" style="margin-top:14px">⚡ 技能类型</div>`;
  RULES.skill_types.forEach(s => {
    html += `
      <div class="rule-card">
        <div class="rule-header" onclick="toggleRule(this.parentElement)">
          <span>⚡ ${s.name}</span>
          <span class="rule-arrow">▼</span>
        </div>
        <div class="rule-body">${s.description}</div>
      </div>
    `;
  });

  // FAQ
  html += `<div class="section-title" style="margin-top:14px">❓ 常见问题</div>`;
  RULES.faq.forEach(f => {
    html += `
      <div class="rule-card">
        <div class="rule-header" onclick="toggleRule(this.parentElement)">
          <span>❓ ${f.q}</span>
          <span class="rule-arrow">▼</span>
        </div>
        <div class="rule-body">${f.a}</div>
      </div>
    `;
  });

  list.innerHTML = html;
}

function toggleRule(card) {
  card.classList.toggle('open');
}

// ===== ASK =====
function renderAskExamples() {
  const examples = [
    { icon: '🎴', q: '关羽有什么技能？' },
    { icon: '🃏', q: '【南蛮入侵】怎么用？' },
    { icon: '📜', q: '游戏流程是什么？' },
    { icon: '🎴', q: '蜀国有哪些武将？' },
    { icon: '🃏', q: '八卦阵的效果是什么？' },
    { icon: '📜', q: '什么是判定？' }
  ];
  document.getElementById('askExamples').innerHTML = examples.map(e => `
    <div class="ask-example" onclick="askQuestion('${e.q.replace(/'/g, "\\'")}')">
      <span class="ask-example-icon">${e.icon}</span>
      <span>${e.q}</span>
    </div>
  `).join('');
}

function askQuestion(question) {
  const answer = getAnswer(question);
  const result = document.getElementById('askResult');
  result.innerHTML = `
    <div style="font-size:12px;color:var(--text2);margin-bottom:8px">👤 ${question}</div>
    <div class="ask-result">🤖 ${answer}</div>
  `;
}

function getAnswer(q) {
  q = q.trim();

  // Hero match
  for (const h of HEROES) {
    if (q.includes(h.name)) {
      return `【${h.name}】（${h.title}）\n` +
        `势力：${h.faction} | 体力：${h.health}\n\n` +
        h.skills.map(s => `【${s.name}】（${s.type}）：${s.description}`).join('\n\n');
    }
  }

  // Faction heroes
  const factionNames = { '蜀': '蜀', '魏': '魏', '吴': '吴', '群': '群' };
  for (const [fname, fnameCN] of Object.entries(factionNames)) {
    if (q.includes(fnameCN + '国') || q.includes(fname)) {
      const heroes = HEROES.filter(h => h.faction === fnameCN);
      return `【${fnameCN}势力武将】共${heroes.length}位：\n` +
        heroes.map(h => `• ${h.name}（${h.title}）`).join('\n');
    }
  }

  // Card match
  const allCards = [...CARDS.basic_cards, ...CARDS.trick_cards, ...CARDS.equipment_cards];
  for (const c of allCards) {
    const cleanQ = q.replace(/【|】/g, '');
    if (cleanQ.includes(c.name) || c.name.includes(cleanQ)) {
      let result = `【${c.name}】（${c.type}）\n效果：${c.description}`;
      if (c.notes) result += `\n📌 ${c.notes}`;
      if (c.attack_range) result += `\n⚔️ 攻击范围：${c.attack_range}`;
      return result;
    }
  }

  // Card type
  if (q.includes('基本牌')) return '基本牌包括：【杀】【闪】【桃】，是最基础的牌。';
  if (q.includes('锦囊牌') || q.includes('锦囊')) return '锦囊牌分为普通锦囊和延时锦囊。普通锦囊立即生效（如【南蛮入侵】【决斗】），延时锦囊需置于判定区生效（如【乐不思蜀】【闪电】）。';
  if (q.includes('装备牌')) return '装备牌包括武器（增加攻击范围）、防具（提供防御效果）、马匹（+1马增加防御距离，-1马增加攻击距离）。';

  // Rules
  if (q.includes('游戏流程') || q.includes('回合') || q.includes('流程')) {
    return '游戏流程（每个回合6个阶段）：\n' +
      '1. 准备阶段 — 触发部分技能\n' +
      '2. 判定阶段 — 处理延时锦囊\n' +
      '3. 摸牌阶段 — 摸两张牌\n' +
      '4. 出牌阶段 — 使用手牌和技能\n' +
      '5. 弃牌阶段 — 弃置超出手牌上限的牌\n' +
      '6. 结束阶段 — 触发部分技能';
  }
  if (q.includes('判定')) return '判定是从牌堆顶翻开一张牌，根据花色、点数或颜色来决定效果。延时锦囊（【乐不思蜀】【闪电】）需要在判定阶段进行判定。';
  if (q.includes('濒死') || q.includes('死亡')) return '当角色体力≤0时进入濒死状态，需使用【桃】或技能回复至1点以上，否则死亡。死亡后亮出身份牌，弃置所有牌。';
  if (q.includes('距离')) return '基本距离为座位差（顺时针或逆时针取较小值）。+1马增加别人与你的距离（防御），-1马减少你与别人的距离（进攻），武器提供攻击范围。';
  if (q.includes('手牌上限') || q.includes('体力上限')) return '角色的手牌上限等于其当前体力值。体力4的角色，手牌上限为4张。';
  if (q.includes('主公')) return '主公是每局游戏的领袖，通常有额外的体力上限和主公技。忠臣帮助主公消灭反贼和内奸，反贼的目标是杀死主公，内奸需要在主公存活时消灭所有人。';
  if (q.includes('技能类型') || q.includes('锁定技')) {
    return '技能类型说明：\n' +
      '• 锁定技：必须发动，无法选择不发动\n' +
      '• 限定技：整局游戏只能发动一次\n' +
      '• 觉醒技：满足条件后必须发动\n' +
      '• 主公技：只有主公身份才能使用\n' +
      '• 转换技：可以将一种牌当另一种牌使用';
  }
  if (q.includes('怎么玩') || q.includes('新手')) {
    return '三国杀基础入门：\n' +
      '• 出牌阶段，用【杀】攻击敌人，用【闪】响应敌人【杀】\n' +
      '• 用【桃】回复体力或救濒死队友\n' +
      '• 合理使用锦囊牌（【南蛮入侵】群体伤害、【无中生有】摸牌等）\n' +
      '• 注意防具和武器的搭配\n' +
      '• 手牌不要超过体力上限，弃牌阶段会强制弃牌';
  }

  // Skill type question
  for (const st of RULES.skill_types) {
    if (q.includes(st.name)) return `【${st.name}】：${st.description}`;
  }

  return '抱歉，我暂时没有找到相关内容。试试搜索武将名（如"关羽"）或卡牌名（如"南蛮入侵"）来获取详细信息！';
}

// ===== INSTALL BANNER =====
function setupInstallBanner() {
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    setTimeout(() => {
      document.getElementById('installBanner').classList.add('show');
    }, 2000);
  });

  document.getElementById('installBtn').addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    document.getElementById('installBanner').classList.remove('show');
  });

  document.getElementById('closeBanner').addEventListener('click', () => {
    document.getElementById('installBanner').classList.remove('show');
  });
}
